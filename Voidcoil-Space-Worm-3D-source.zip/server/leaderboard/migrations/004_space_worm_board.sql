-- Space Worm: peak worm length reached during a single life (higher is better).
-- Board ID and rules version are immutable once scores exist; changed rules need a new board ID.
INSERT INTO game_lb_boards
(namespace,id,rules_version,direction,min_score,max_score,min_duration_ms,max_duration_ms,`open`)
VALUES
('production','peak-length-v1','v1','desc',1,100000,3000,1800000,TRUE);
