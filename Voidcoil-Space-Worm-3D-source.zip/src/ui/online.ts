/**
 * Opt-in global leaderboard for peak length per life. Wraps the generated guest client with
 * an honest status model; any failure falls back to local records without blocking play.
 */
import { createLeaderboardClient, type Leaderboard, type RunTicket } from '../../leaderboard.js'
import { lifeEligibleForBoard } from '../game/rules'

export type OnlineStatus = 'off' | 'unranked' | 'short' | 'pending' | 'submitted' | 'unavailable'
export type OnlineOutcome = { status: OnlineStatus; rank?: number; best?: number }

export class Online {
  private client = createLeaderboardClient({ identity: 'guest', boardId: 'peak-length-v1', rulesVersion: 'v1' })
  private ticket: Promise<RunTicket | null> = Promise.resolve(null)
  cached: Leaderboard | null = null

  /** Called at the start of every life. Does nothing unless the player opted in. */
  beginLife(optIn: boolean, name: string, unranked: boolean): void {
    if (!optIn || unranked) {
      this.ticket = Promise.resolve(null)
      return
    }
    this.ticket = (async () => {
      try {
        const guest = await this.client.ensureGuest(name)
        if (!guest.ok) return null
        const run = await this.client.beginRun()
        return run.ok ? run.value : null
      } catch {
        return null
      }
    })()
  }

  async endLife(optIn: boolean, unranked: boolean, peakLength: number, durationMs: number): Promise<OnlineOutcome> {
    if (!optIn) return { status: 'off' }
    if (unranked) return { status: 'unranked' }
    if (!lifeEligibleForBoard(peakLength, durationMs)) return { status: 'short' }
    try {
      const ticket = await this.ticket
      this.ticket = Promise.resolve(null)
      if (!ticket) return { status: 'unavailable' }
      let sent = await this.client.submitRun(ticket, Math.floor(peakLength), Math.min(1_800_000, Math.round(durationMs)))
      if (!sent.ok) sent = await this.client.retryRun(ticket)
      if (!sent.ok) return { status: 'unavailable' }
      const board = sent.value.leaderboard
      if (board.ok) {
        this.cached = board.value
        return { status: 'submitted', rank: board.value.myRank?.rank, best: board.value.myRank?.score }
      }
      return { status: 'submitted' }
    } catch {
      return { status: 'unavailable' }
    }
  }

  async list(limit = 20): Promise<Leaderboard | null> {
    try {
      const r = await this.client.list(limit)
      if (!r.ok) return null
      this.cached = r.value
      return r.value
    } catch {
      return null
    }
  }
}
